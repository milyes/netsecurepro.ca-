
# Configuration SAML pour IA_LOGIC / NetSecurePro

**Identité du fournisseur (IdP)** : Google  
**Entity ID** : `https://accounts.google.com/o/saml2?idpid=C03ccq3dq`  
**SSO URL** : `https://accounts.google.com/o/saml2/idp?idpid=C03ccq3dq`  
**Certificat X.509** : Google_2030-4-29-115731_SAML2_0  
**SHA-256 fingerprint** :  
47:E5:C7:48:12:40:34:B9:D9:D5:BF:F5:96:7A:29:10:EC:58:55:2B:7F:6D:86:2A:D0:0F:69:DE:42:FC:58:21
